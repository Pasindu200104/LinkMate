import { StatusBar } from "expo-status-bar";

<StatusBar hidden={true}/>